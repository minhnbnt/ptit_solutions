import danhsachsinhvien1.SinhVien;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;

public class Main {

	@SuppressWarnings("unchecked")
	public static void main(String[] args)
	    throws IOException, ClassNotFoundException {

		FileInputStream fileStream = new FileInputStream("SV.in");
		ObjectInputStream objStream = new ObjectInputStream(fileStream);

		List<SinhVien> students = (List<SinhVien>)objStream.readObject();
		objStream.close();

		students.forEach(System.out::println);
	}
}
