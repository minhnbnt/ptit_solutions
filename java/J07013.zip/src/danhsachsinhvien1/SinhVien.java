package danhsachsinhvien1;

import java.io.Serializable;
import java.text.ParseException;
import java.util.Date;

public class SinhVien implements Serializable {

    private String ma, ten, lop;
    private Date ngaysinh;
    private float gpa;

    public SinhVien(int id, String ten, String lop, String ngaysinh, float gpa)
        throws ParseException {

        this.ngaysinh = Constants.dateFormat.parse(ngaysinh);
        this.ma = String.format("B20DCCN%03d", id);
        this.ten = ten;
        this.lop = lop;
        this.gpa = gpa;
    }

    @Override
    public String toString() {

        String formattedDate = Constants.dateFormat.format(ngaysinh);
        
        return String.format("%s %s %s %s %.2f",
            ma, ten, lop, formattedDate, gpa);
    }
}
