package danhsachsinhvien1;

import java.text.SimpleDateFormat;

public class Constants {
    public static SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
}
