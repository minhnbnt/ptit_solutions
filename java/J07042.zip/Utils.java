import test.Pair;

public class Utils {

	public static int gcd(int a, int b) {

		while (a * b != 0) {

			if (a > b) {
				a %= b;
			} else {
				b %= a;
			}
		}

		return a + b;
	}

	public static boolean isValidPair(Pair p) {

		if (p.getFirst() >= p.getSecond()) {
			return false;
		}

		return gcd(p.getFirst(), p.getSecond()) == 1;
	}
}
