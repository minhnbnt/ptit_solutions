import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import test.Pair;

public class Main {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception {

		FileInputStream fileStream = new FileInputStream("DATA.in");
		ObjectInputStream objectStream = new ObjectInputStream(fileStream);

		List<Pair> pairs = (List<Pair>)objectStream.readObject();
		objectStream.close();

		SetPair set = new SetPair();
		List<Pair> filteredPairs = new ArrayList<>();
		for (Pair p : pairs) {

			if (Utils.isValidPair(p)) {
				continue;
			}

			if (set.contains(p)) {
				continue;
			}

			filteredPairs.add(p);
			set.add(p);
		}

		Collections.sort(filteredPairs);
		filteredPairs.forEach(System.out::println);
	}
}
