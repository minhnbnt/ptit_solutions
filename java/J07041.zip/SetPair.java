import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import test.Pair;

public class SetPair {

	private final Map<Integer, Set<Integer>> map;

	public SetPair() {
		map = new HashMap<>();
	}

	public boolean contains(Pair pair) {
		Set<Integer> seconds = map.get(pair.getFirst());
		return seconds != null && seconds.contains(pair.getSecond());
	}

	public boolean add(Pair pair) {
		return map.computeIfAbsent(pair.getFirst(), k -> new HashSet<>())
		    .add(pair.getSecond());
	}
}
